<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Add</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
<link rel="stylesheet" type="text/css" href="css/custom.css">
<script type="text/javascript">
  {
  window.history.go(3)
  }
</script> 
</head>

<body>
<!--add data to database by php-->
<div class="container">
	<div class="row">
    		<div class="col-md-6 col-md-offset-3"><img src="img/vision Camera.png" alt="title" width="60%"></div>
  			
  	</div>
<?php				
	 //$server = 'mysql.myblog.myvisionphotography.net';
//     $user = 'myblogmyvisionph';
//     $password = 'Tri1604!?$';
//     $database = 'myblog_myvisionphotograp';
	 require 'dbconnect.php';
	//$dbh = new PDO("mysql:host=mysql.myblog.myvisionphotography.net;dbname=myblog_myvisionphotograp", "myblogmyvisionph","Tri16!?04$1986"); 
	///http://www.w3schools.com/php/php_file_upload.asp
	//for check extension and upload....
	$allowedExts = array("gif", "jpeg", "jpg", "png");
	$temp = explode(".", $_FILES["file"]["name"]);
	$extension = end($temp);
/*	if($_FILES['file']['error'] > 0) {
        			echo "Error: {$_FILES["file"]["error"]}"."<br />\n";
        		}
*/
/*	if(file_exists("img/".$_FILES['file']['name']))  {
        			echo "<b>Error, the file {$_FILES["file"]["name"]} already exists on the server</b><br />\n";
        		}
*/	
	 $SKU = $_POST['SKU'];
	 $Title = $_POST['Title'];
	 $Cameratype = $_POST['CameraType'];
	 $Brand = $_POST['Brand'];
	 $Description = $_POST['Description'];
	 $Cost = $_POST['Cost'];
	 $Retail = $_POST['Retail'];
    
	 //$_SERVER['DOCUMENT_ROOT'];

	$location= "http://mysite1.myvisionphotography.net/photo/".$_FILES['file']['name'];
	 if($SKU !='' && $Title !='' && $Cameratype!='' && $Brand !='' && (($_FILES["file"]["type"] == "image/gif")
|| ($_FILES["file"]["type"] == "image/jpeg")
|| ($_FILES["file"]["type"] == "image/jpg")
|| ($_FILES["file"]["type"] == "image/pjpeg")
|| ($_FILES["file"]["type"] == "image/x-png")
|| ($_FILES["file"]["type"] == "image/png"))
&& ($_FILES["file"]["size"] < 2000000)
&& in_array($extension, $allowedExts))
	 {
		$checksql = $dbh->prepare("select SKU from products where SKU = '$SKU' and Title = '$Title'");
		$checksql->execute();
		$i=0;
		while ($row = $checksql->fetch())
		{
			$i++;	
		}
		if($i<1){
			if($_FILES['file']['error'] > 0) {
						echo "Error: {$_FILES["file"]["error"]}"."<br />\n";
					}
			else
			{
				if(file_exists("img/".$_FILES['file']['name']))  {
        			echo "<b>Error, the file {$_FILES["file"]["name"]} already exists on the server</b><br />\n";
        		}
				else
				{
					
						move_uploaded_file($_FILES['file']['tmp_name'], "photo/".$_FILES['file']['name']);
						$insposts = $dbh->prepare("insert into products (sku, title, camtype_id, brand_id, description, cost, retail, location) values ('$SKU','$Title','$Cameratype','$Brand','$Description','$Cost','$Retail','$location')");
						$insposts->execute();
                        
						echo "<h4>Upload success</h4>";
						echo "<br />\n";
						echo '<form class="form-horizontal" role="form" name="addform" method="post" 
            enctype="multipart/form-data" action="add.php" onSubmit="return validateadd();">
            <span id="message_line"></span>
		<div class="row">
        	<div class="col-md-6 col-md-offset-3">
			<div class="table-responsive">
                <table class="table table-hover">
                
                    <tr>
                        <th>SKU*</th>
                        <td><input type="text" class="form-control" name="SKU" id="inputSKU" placeholder="SNDL000300" required></td>            
                    </tr>
                    <tr>
                        <th>Title*</th>
                        <td><input type="text" class="form-control" name="Title" id="inputTitle" placeholder="Canon 7D" required></td>                
                    </tr>
                    <tr>
                        <th>Camera Type*</th>
                        <td><select name="CameraType" id="inputType" class="form-control" required>
                                <option value="" ></option>
                                <option id="DSLR" value="2">DSLR</option>
                                <option id="PNS" value="1">Point and Shoot</option>
                                <option id="Pola" value="3">Polaroid</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Brand*</th>
                        <td><select name="Brand" id="inputBrand" class="form-control" required>
                                <option value=""></option>
                                <option id="Casio" value="1">Casio</option>
                                <option id="Canon" value="2">Canon</option>
                                <option id="Fuji" value="3">FujiFilm</option>
                                <option id="Kodak" value="4">Kodak</option>
                                <option id="Nikon" value="5">Nikon</option>
                                <option id="Olympus" value="6">Olympus</option>
                                <option id="Panasonic" value="7">Panasonic</option>
                                <option id="Polaroid" value="8">Polaroid</option>
                                <option id="Samsung" value="9">Samsung</option>
                                <option id="Sony" value="10">Sony</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Description*</th>
                        <td><textarea name="Description" class="form-control" rows="3" required></textarea></td>
                    </tr>
                    <tr>
                        <th>Cost*</th>
                        <td><input type="number" name="Cost" class="form-control" id="inputCost" placeholder="499.99" required></td>
                    </tr>
                    <tr>
                        <th>Retail*</th>
                        <td><input type="number" name="Retail" class="form-control" id="inputRetail"  placeholder="499.99" required></td>
                    </tr>
                    <tr>
                        <th>Image*</th>
                        <td><input type="file" name="file" class="form-control" id="inputImage" required></td>
                    </tr>
                </table>
        	</div>
            </div>
		</div>
      <div class="form-group">
        <div class="col-sm-offset-6 col-sm-6">
          <button type="submit" class="btn btn-default">Submit</button>
          <button type="Reset" class="btn btn-default" value="reset">Cancel</button>
        </div>
      </div>
	</form>';
						
		
		}
		}
		}
	 }
	 else
		echo "Invalid file.";
		echo "<a href='add.html'>&lt;-- return to add page</a>";
?>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/custom.js"></script>
</body>
</html>
