<?php
require 'dbconnect.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Search</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/custom.css">
</head>

<body>
<div class="container">
	<div class="row">
    		<div class="col-md-8"><img src="img/vision Camera.png" alt="title" width="30%"></div>
  		<!--	<div class="col-md-4"><span class="glyphicon glyphicon-shopping-cart"></span>My Cart(<span id="count">0</span>)</div> -->
  	</div>
	<div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-inverse" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="index.php?Home">Home</a></li>
                
                <li class="dropdown active">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Products<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                   <?
include 'nav.php';
                   ?>
                  </ul>
                </li>
                <li><a href="index.php?About">About</a></li>
                <li><a href="index.php?Contact">Contact</a></li>
              </ul>
              
              <form class="navbar-form " action = "search.php" method = "post">
            		<input type="text" name = "qry" class="form-control" placeholder="Search...">
                    <input type = "submit" name = "submit" value = "Search"/>
            </form>
            </div>
          </div>
        </div>

      </div>
    </div>
    <?php
    if(isset($_GET['About'])){
        include 'About.php';}
    else if(isset($_GET['Contact'])){
        include 'Contact.php';}
    else if(isset($_GET['Home'])){
        include 'Home.php';}
    else{        
     echo '<div class="container">';
      echo  '<div class="row">';
     echo '<div class="col-md-8 col-md-offset-2">';
//require 'dbconnect.php';
// $dbh = new PDO("mysql:host=mysql.myblog.myvisionphotography.net;dbname=myblog_myvisionphotograp", "myblogmyvisionph", "Tri16!?04$1986");
//run a select statement off the text value that is a loose keyword search
$submit = $_POST['submit'];
$qry = $_POST['qry'];
//need to do a loose keyword search across 3 tables
if (!empty($qry)){
$sql= $dbh->prepare("SELECT products.id,products.sku,products.title,products.description,
 products.cost,products.retail,products.location,brand.brand_name,camtype.cameratype 
  FROM  products,brand,camtype 
  WHERE (products.sku like '%$qry%'
  or products.title  like '%$qry%'
  or products.description  like '%$qry%'
  or brand.brand_name like '%$qry%'
  or camtype.cameratype like '%$qry%')
  and products.brand_id = brand.id
  and  products.camtype_id = camtype.id ");
$sql->execute();
$i = 0; 
while ($row = $sql->fetch()){
  $id= $row['id'];
  $sku = $row['sku'];
  $title = $row['title'];
  $description = $row['description'];
  $cost = $row['cost'];
  $retail = $row['retail'];
  $piclocation = $row['location']; 
  $brand = $row['brand_name'];
  $camtype = $row['cameratype'];
//
//$output[] = $title.'<br/>'.$brand.'<img src = "thumbnail.php?pic='.$piclocation.'&ht=75&wd=75"/>'.$description.'
//   <a href = "product.php?pid='.$id.'">Read More</a><br/>$'.$cost.'<br/><br/>';
    echo $title.'<br/>'.$brand.'<br/><img src = "thumbnail.php?pic='.$piclocation.'&ht=75&wd=75"/>'.$description.'
   <a href = "product.php?pid='.$id.'">Read More</a><br/>$'.$cost.'<br/><br/>';
$i++;
}
 $message = 'Your search for '.$qry.' generated '.$i.' results';
    echo $message;
//need to show reduced information about product and link to product page. Maybe a buy now button
//echo '<pre>';
//print_r($output);
//var_dump($sqlrow);
//echo '</pre>';
}
else {
  echo '<center><h4 style="color:red">Empty search. Please enter the search value.</h4></center>';

}
echo '</div>';
    echo '</div>';
    echo '</div>';}
?>
  <hr>
     <div class="footer">
         <div class="col-md-4"><p>&copy; Company 2014</p></div>
        <div class="col-md-8"><b>Follow us at </b><a href="http://www.facebook.com"><i class="fa fa-facebook-square fa-3x"></i></a><a href="http://www.linkedin.com"><i class="fa fa-linkedin-square fa-3x"></i></a>
         </div>
     </div>
</div><!-- /container -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/custom.js"></script>
</body>
</html>  