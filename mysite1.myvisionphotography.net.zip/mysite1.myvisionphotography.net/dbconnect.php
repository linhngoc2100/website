<?
$dbh = new PDO("mysql:host=mysql.myblog.myvisionphotography.net;dbname=myblog_myvisionphotograp", "myblogmyvisionph","Tri16!?04$1986");?>