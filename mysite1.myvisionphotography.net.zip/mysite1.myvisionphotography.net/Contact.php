
	
	<div class="container">
		<div class="row">
            <div class="col-md-8 col-md-offset-2">
                <img src="img/contact_us.png" alt="title" width="100%">
                <hr/>
                <br/>
                <i class="fa fa-envelope"></i><p>tomnguyen2100@yahoo.com</p>
                <i class="fa fa-phone"></i><p>888-888-1234</p>
                <form name="text_form" role="form" action = "send.php" method = "post" onSubmit="return validateform();">
                <span id="message_line"></span>
                          <fieldset>
                            <label for="name">Name</label>
                            <input type="text" name="inputName" id="name" class="form-control" placeholder="Your name" />
                            <label for="email">Email</label>
                            <input type="email" name="inputEmail" id="email" class="form-control" placeholder="Your email" />
                            <label for="Message">Message</label>
                            <textarea class="form-control" rows="3"  name="t_mess" ></textarea>
                              <br/>
                         <button type="submit" name="submit1" class="btn btn-default">Send</button>
                        <button type="reset" value="Reset"  class="btn btn-default">Reset</button>
                          </fieldset>
                          
                </form>
            </div>
		</div>
	</div>	
    <hr/>