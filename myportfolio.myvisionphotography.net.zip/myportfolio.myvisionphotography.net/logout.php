<?
ob_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Log In</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
<link rel="stylesheet" type="text/css" href="css/custom.css">
</head>

<body>
<div class="container">
	<div class="row">
    		<div class="col-md-6 col-md-offset-3"><img src="img/vision Camera.png" alt="title" width="60%"></div>
  			
  	</div>
  	<?php
    session_start();
    
    if(isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-1000,'/');
        session_destroy();        
        }
    ?>
   <h2>You have now successfully logged out.</h2>
        
	<center><a href="login.html">Click HERE to log back in</a></center>
 <div class="footer">
        <p>&copy; Company 2014</p>
     </div>
</div><!-- /container -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>