<?
ob_start();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
<link rel="stylesheet" type="text/css" href="css/custom.css">
<!-- prevent go back-->
<script type="text/javascript">

  {
  window.history.go(3)
  }
</script> 
</head>

<body>
<div class="container">
	
<?php
	$username = "myshopping";
	$password = "sp2014";
	$salt = "45Gxkj9583lPMdxoekfg";
	$encryptedPass= crypt($password, $salt);
	
	$entered_user = trim($_POST['username']);
	$enteredPass = trim($_POST['password']);
	
	$enteredPass = crypt($enteredPass, $salt);
	
	if(($username == $entered_user) && ($encrypted_password == $entered_password)) {
            echo "<h2>Welcome ".$username.", You are now logged in.</h2>\n";
	   
            
	
	session_start();
	$_SESSION['valid'] = 1;
	$_SESSION['user'] = $username;
	echo '<div class="row">
    		<div class="col-md-6 col-md-offset-3"><img src="img/vision Camera.png" alt="title" width="60%"></div>
  			
  	</div>';
  	echo '<a href="logout.php">Logout</a>';
	echo '<form class="form-horizontal" role="form" name="addform" method="post" 
            enctype="multipart/form-data" action="add.php" onSubmit="return validateadd();">
            <span id="message_line"></span>
		<div class="row">
        	<div class="col-md-6 col-md-offset-3">
			<div class="table-responsive">
                <table class="table table-hover">
                
                    <tr>
                        <th>SKU*</th>
                        <td><input type="text" class="form-control" name="SKU" id="inputSKU" placeholder="SNDL000300" required></td>            
                    </tr>
                    <tr>
                        <th>Title*</th>
                        <td><input type="text" class="form-control" name="Title" id="inputTitle" placeholder="Canon 7D" required></td>                
                    </tr>
                    <tr>
                        <th>Camera Type*</th>
                        <td><select name="CameraType" id="inputType" class="form-control" required>
                                <option value="" ></option>
                                <option id="DSLR" value="2">DSLR</option>
                                <option id="PNS" value="1">Point and Shoot</option>
                                <option id="Pola" value="3">Polaroid</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Brand*</th>
                        <td><select name="Brand" id="inputBrand" class="form-control" required>
                                <option value=""></option>
                                <option id="Casio" value="1">Casio</option>
                                <option id="Canon" value="2">Canon</option>
                                <option id="Fuji" value="3">FujiFilm</option>
                                <option id="Kodak" value="4">Kodak</option>
                                <option id="Nikon" value="5">Nikon</option>
                                <option id="Olympus" value="6">Olympus</option>
                                <option id="Panasonic" value="7">Panasonic</option>
                                <option id="Polaroid" value="8">Polaroid</option>
                                <option id="Samsung" value="9">Samsung</option>
                                <option id="Sony" value="10">Sony</option>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th>Description*</th>
                        <td><textarea name="Description" class="form-control" rows="3" required></textarea></td>
                    </tr>
                    <tr>
                        <th>Cost*</th>
                        <td><input type="number" name="Cost" class="form-control" id="inputCost" placeholder="499.99" required></td>
                    </tr>
                    <tr>
                        <th>Retail*</th>
                        <td><input type="number" name="Retail" class="form-control" id="inputRetail"  placeholder="499.99" required></td>
                    </tr>
                    <tr>
                        <th>Image*</th>
                        <td><input type="file" name="file" class="form-control" id="inputImage" required></td>
                    </tr>
                </table>
        	</div>
            </div>
		</div>
      <div class="form-group">
        <div class="col-sm-offset-6 col-sm-6">
          <button type="submit" class="btn btn-default">Submit</button>
          <button type="Reset" class="btn btn-default" value="reset">Cancel</button>
        </div>
      </div>
	</form>';
}
	else {
            $page = file_get_contents("errorlogin.html");
            echo $page;
            exit;
            }
?>

</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>
