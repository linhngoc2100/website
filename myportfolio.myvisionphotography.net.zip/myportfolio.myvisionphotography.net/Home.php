
     <div class="container">
         
                <div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
                  <!-- Indicators -->
                  <ol class="carousel-indicators">
                    <li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="1"></li>
                    <li data-target="#carousel-example-generic" data-slide-to="2"></li>
                  </ol>
        
                  <!-- Wrapper for slides -->
                  <div class="carousel-inner">
                    <div class="item active">
                        <img class="homepic" src="img/HR_G1X_MARKII_B.jpg" alt="Canon G1X Mark2" >
                        <div class="carousel-caption">
                            <h3 id="cap_title">Canon PowerShot G1 X Mark II Black</h3>
                            <p id="cap_title2">High-End, Advanced Digital Cameras</p>
                        </div>
                    </div>
                    
                    <div class="item">
                        <img class="homepic" src="img/Sony_Cybershot_H400.jpg" alt="Sony Cyber Shot H400" >
                        <div class="carousel-caption">
                            <h3 id="cap_title">Sony Cyber Shot H400</h3>
                            <p id="cap_title2">Sony High Zoom Point and Shoot Camera</p>
                        </div>
                    </div>
                    
                    <div class="item">
                        <img class="homepic" src="img/Nikon_Coolpix_p600.jpg" alt="Nikon Coolpix P600" >
                        <div class="carousel-caption">
                            <h3 id="cap_title">Nikon Coolpix P600</h3>
                            <p id="cap_title2">The highest zoom ratio in COOLPIX history-optical Zoom 60x</p>
                        </div>
                    </div>
                  </div>
        
                  <!-- Controls -->
                  <a class="left carousel-control" href="#carousel-example-generic" data-slide="prev">
                    <span class="glyphicon glyphicon-chevron-left"></span>
                  </a>
                  <a class="right carousel-control" href="#carousel-example-generic" data-slide="next">
                    <span class="glyphicon glyphicon-chevron-right"></span>
                  </a>
                </div>
        	
    </div>

     <hr>
     
