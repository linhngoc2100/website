// JavaScript Document
$('.carousel').carousel({
  interval: 2000
})


    
 
function validateform() {

	var messageLine =document.getElementById("message_line");
    var first=document.text_form.inputName.value.indexOf("<");
	
	if(document.forms.text_form.inputName.value =="")
	{
        
		document.forms.text_form.inputName.focus();
        messageLine.innerHTML ="Please enter your name.";
		return false;
	}
    //check if the user enter the tag
    if(first==0)
    {
        
		document.forms.text_form.inputName.focus();
        messageLine.innerHTML ="Please enter your valid name without <.";
		return false;
	}
	//check email
// this technique is from http://white-hat-web-design.cok.uk/blog/javascript-validation
    var reg=/^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
	if(document.forms.text_form.inputEmail.value =="" )
	{
		document.forms.text_form.inputEmail.focus();
        messageLine.innerHTML ="Please enter your email.";
		return false;
	}
    if(reg.test(document.forms.text_form.inputEmail.value)==false)
    {
     document.forms.text_form.inputEmail.focus();
        messageLine.innerHTML ="Please enter your  valid email.";
		return false;   
    }
    
    if(document.forms.text_form.t_mess.value =="")
	{
		document.forms.text_form.inputEmail.focus();
        messageLine.innerHTML ="Please enter your message.";
		return false;
	}	

}

function validateadd(){
    
    
}
 