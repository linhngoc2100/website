<?php
require 'dbconnect.php';
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Contact</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
<link rel="stylesheet" href="css/font-awesome.min.css">
<link rel="stylesheet" type="text/css" href="css/custom.css">
</head>

<body>
<div class="container">
  <div class="row">
        <div class="col-md-8"><img src="img/vision Camera.png" alt="title" width="30%"></div>
        <div class="col-md-4"><span class="glyphicon glyphicon-shopping-cart"></span>My Cart(<span id="count">0</span>)</div>
    </div>
  <div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-inverse" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="index.php?Home">Home</a></li>
                
                <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Products<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                   <?
include 'nav.php';
                   ?>
                  </ul>
                </li>
                <li><a href="index.php?About">About</a></li>
                <li><a href="index.php?Contact">Contact</a></li>
              </ul>
              
              <form class="navbar-form " action = "search.php" method = "post">
                <input type="text" name = "qry" class="form-control" placeholder="Search...">
                    <input type = "submit" name = "submit" value = "Search"/>
            </form>
            </div>
          </div>
        </div>

      </div>
    </div>
    <?php
    if(isset($_GET['About'])){
        include 'About.php';}
    else if(isset($_GET['Contact'])){
        include 'Contact.php';}
    else if(isset($_GET['Home'])){
        include 'Home.php';}
    else{        
     echo '<div class="container">';
      echo  '<div class="row">';
     echo '<div class="col-md-8 col-md-offset-2">';
    
 $name = $_POST['inputName'];
$email = $_POST['inputEmail'];
$t_mess = $_POST['t_mess'];
if($name !='' && $email !='' && $t_mess!='')
{
   $checksql = $dbh->prepare("select name from products where name = '$name' and email = '$email' and t_message='$t_mess'");
    $checksql->execute();
    $i=0; 
        while ($row = $checksql->fetch())
    {
      $i++; 
    }
        if($i<1)
        {
           $insposts = $dbh->prepare("insert into chat2 (name, email, t_message) values ('$name','$email','$t_mess')");
            $insposts->execute(); 
            echo "<h3 style='color:red'>successfully sent</h3>";
            echo '<img src="img/contact_us.png" alt="title" width="100%">
                <hr/>
                <br/>
                <i class="fa fa-envelope"></i><p>tomnguyen2100@yahoo.com</p>
                <i class="fa fa-phone"></i><p>888-888-1234</p>
                <form name="text_form" role="form" action = "send.php" method = "post" onSubmit="return validateform();">
                <span id="message_line"></span>
                          <fieldset>
                            <label for="name">Name</label>
                            <input type="text" name="inputName" id="name" class="form-control" placeholder="Your name" />
                            <label for="email">Email</label>
                            <input type="email" name="inputEmail" id="email" class="form-control" placeholder="Your email" />
                            <label for="Message">Message</label>
                            <textarea class="form-control" rows="3"  name="t_mess" ></textarea>
                              <br/>
                         <button type="submit" name="submit1" class="btn btn-default">Send</button>
                        <button type="reset" value="Reset"  class="btn btn-default">Reset</button>
                          </fieldset>
                          
                </form>';
            
        }
}
else{
    echo "Error input.";   
}

    echo '</div>';
    echo '</div>';
    echo '</div>';
   
    }


        ?>  
    

     <hr>
     <div class="footer">
         <div class="col-md-4"><p>&copy; Company 2014</p></div>
        <div class="col-md-8"><b>Follow us at </b><a href="http://www.facebook.com"><i class="fa fa-facebook-square fa-3x"></i></a><a href="http://www.linkedin.com"><i class="fa fa-linkedin-square fa-3x"></i></a>
         </div>
     </div>
</div><!-- /container -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/custom.js"></script>
</body>
</html>
