<?php
session_start();
$sessid = session_id();
require 'dbconnect.php';
$pid = $_GET['pid'];
echo 'pid '.$pid;
$addprod = $_GET['addprod'];
$qty = $_POST['qty'];
$submit = $_POST['submit'];
if ($submit == 'Add to Cart'){
//check first if product already in table, update qty else insert
$checksql= 	$dbh->prepare("select count(*) as numitems from cart_items where sessionid = ? and productid = ?");
$checksql->execute(array($sessid,$pid));
$checksqlrow = $checksql->fetch();
$num = $checksqlrow['numitems'];
if ($num > 0){
$upsql=	$dbh->prepare("update cart_items set quantity = ? where sessionid = ? and productid = ?");
$upsql->execute(array($qty,$sessid,$pid));
}
else {
$sql = $dbh->prepare("insert into cart_items(sessionid,productid,quantity) values (?,?,?)");
$sql->execute(array($sessid,$pid,$qty));
}
$msg = ' Product added!';
echo $msg;
}

?>
<html>
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>DSLR</title>
<link rel="stylesheet" type="text/css" href="css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap-theme.css">
<link rel="stylesheet" type="text/css" href="css/custom.css">
</head>

<body>
<div class="container">
	<div class="row">
    		<div class="col-md-8"><img src="img/vision Camera.png" alt="title" width="30%"></div>
  		<!--	<div class="col-md-4"><span class="glyphicon glyphicon-shopping-cart"></span>My Cart(<span id="count">0</span>)</div>  -->
  	</div>
	<div class="navbar-wrapper">
      <div class="container">

        <div class="navbar navbar-inverse" role="navigation">
          <div class="container">
            <div class="navbar-header">
              <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
              </button>
              
            </div>
            <div class="navbar-collapse collapse">
              <ul class="nav navbar-nav">
                <li><a href="index.php?Home">Home</a></li>
                
                <li class="dropdown active">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Products<b class="caret"></b></a>
                  <ul class="dropdown-menu">
                   <?
include 'nav.php';
                   ?>
                  </ul>
                </li>
                <li><a href="index.php?About">About</a></li>
                <li><a href="index.php?Contact">Contact</a></li>
              </ul>
              
              <form class="navbar-form " action = "search.php" method = "post">
            		<input type="text" name = "qry" class="form-control" placeholder="Search...">
                    <input type = "submit" name = "submit" value = "Search"/>
            </form>
            </div>
          </div>
        </div>

      </div>
    </div>
         <?
        if(isset($_GET['About'])){
        include 'About.php';}
    else if(isset($_GET['Contact'])){
        include 'Contact.php';}
    else if(isset($_GET['Home'])){
        include 'Home.php';}
    else{        
     echo '<div class="container">';
      echo  '<div class="row">';
     echo '<div class="col-md-8 col-md-offset-2">';
         echo "MESSAGE ".$msg;
 //get all cameras of this type and and list with a thumbnail and information
 //$sql= $dbh->prepare("SELECT id,sku,title,description,cost,retail,location FROM `tom_products` WHERE cameratype = ?");

 $sql= $dbh->prepare("SELECT products.id,products.sku,products.title,products.description,
  products.cost,products.retail,products.location,brand.brand_name,camtype.cameratype 
  FROM  products,brand,camtype 
  WHERE products.id = ?
  and products.brand_id = brand.id
  and  products.camtype_id = camtype.id ");
 $sql->bindValue (1,$pid);
$sql->execute();
while ($row = $sql->fetch()){
    
  $id= $row['id'];
  $sku = $row['sku'];
  $title = $row['title'];
  $description = $row['description'];
  $cost = $row['cost'];
  $retail = $row['retail'];
  $piclocation = $row['location']; 
  $brand = $ro