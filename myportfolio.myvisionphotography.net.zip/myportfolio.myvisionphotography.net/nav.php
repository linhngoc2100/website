
<?php
$sql = $dbh->prepare("select id,cameratype from camtype");
$sql->execute();
//this is how to error handle when you have no syntax errors
//print_r($sql->errorInfo());

while ($row = $sql->fetch()){
  $camid = $row[0];
  $camtype = $row[1];
        echo '<li><a href="categories.php?camid='.$camid.'" id='.$camtype.'>'.$camtype.'</a></li>';
}
?>