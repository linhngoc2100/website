
	
	<div class="container">
		<div class="row">
            <div class="col-md-8 col-md-offset-2">
                <img src="img/about_us.png" alt="title" width="100%">
                <hr/>
                <br/>
                <h4>Vision Camera is the world’s only full-service destination for cameras. We offer the best selection and prices on consumer cameras.</h4>
                <p>Vision Camera is listed as one of the top five camera retailers by Consumer Reports, “Best of the Web” by Forbes.com, Internet Retailers
                Top 100, and is the official Electronics Retailer of the NY Giants and by the others.</p>
                <h4>Warehouse</h4>
                <p>At the 120,000 square-foot Adorama warehouse, we use the latest technology to distribute items to our store in New York and to customers worldwide. 
                When items are received, they are sorted and stocked using a computer system that eliminates the possibility of errors. When an order is received, 
                we use handheld computers to find your items. Once selected, the items are sent to the shipping department for distribution.</p>
                <p>This proprietary warehouse management system maximizes efficiency, leading to blazingfast order fulfillment time, increased accuracy and 
                enhanced customer service. It helps us to keep costs down, leading to lower prices for our customers. The end result is fast, error-free 
                shipments and accurate inventory so customers quickly get exactly what they want.</p>
                
            </div>
		</div>
	</div>	
    <hr>
